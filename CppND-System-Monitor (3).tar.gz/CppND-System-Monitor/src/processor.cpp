#include "processor.h"
#include"linux_parser.h"

// TODO: Return the aggregate CPU utilization
float Processor::Utilization() { 
    long uptime=LinuxParser::UpTime();
    long total = LinuxParser::Jiffies();
    long idle = LinuxParser::IdleJiffies();
    long active=LinuxParser::ActiveJiffies();
    while(LinuxParser::UpTime()!=uptime+5){}//just to experiment ,we can use sleep function also
    long new_total = LinuxParser::Jiffies();
    long new_idle = LinuxParser::IdleJiffies();
    long new_active=LinuxParser::ActiveJiffies();   
    float cpu_percent=(new_active-active)/(new_total-total)*100;
    return cpu_percent;
 }